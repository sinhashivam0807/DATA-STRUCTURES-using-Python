#Binary Search
import numpy as np
my_value=int(input("Enter the number to search"))
n=int(input("Enter number of element to be added in array"))
list=np.zeros(n)
pos=0


# function to create list
def insert(list,n):
    for j in range(0,n):
        new=int(input("Enter the element")
        list[j]=new
    else:
        print("Array is ",list)

#function for Search
def search(list,my_value):
    lower=0
    upper=len(list)
    mid=lower+upper//2
    while(lower<=upper):
        if(list[mid]==my_value):
            globals()['pos']=mid
            return True
        else:
            if(list[mid]<my_value):
                lower=mid+1
            else:
                upper=mid-1
            return False

# Calling Function      
insert(list,n)
if(search(list,my_value)):
    print("Found at",pos+1)
else:
    print("Not found")
