# linear search

import numpy as np
my_value=int(input("Enter the number to search"))
n=int(input("Enter number of element to be added in array"))
list=np.zeros(n)

# function to create list
def insert(list,n):
    for j in range(0,n):
        new=int(input("Enter the element"))
        #list.append(new)
        list[j]=new
    else:
        print("Array is ",list)


    
# function to search the element
def search(list,my_value):
    for i in range(0,len(list)):
        if(list[i]==my_value):
            print("Element found at ",i+1)
    else:
        return(0)   




#Calling Function
insert(list,n)
search(list,my_value)
