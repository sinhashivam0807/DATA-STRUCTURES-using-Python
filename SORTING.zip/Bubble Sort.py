list=[22,55,11,69,3,2,5,10,25]

def sort(list):
        
    print("Given List is",globals()['list'])

    for i in range(len(list)-1,0,-1):
        for j in range(0,i):
            if list[j+1]<list[j]:
                temp=list[j]
                list[j]=list[j+1]
                list[j+1]=temp
    
    print("Sorted List is",list)

sort(list)

