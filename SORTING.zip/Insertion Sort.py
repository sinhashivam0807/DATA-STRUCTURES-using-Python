list=[11,25,4,3,5,9,4,2,98,101,31]


#function for sorting
def sort(list):
    for index in range(1,len(list)):
        current_val=list[index]
        pos=index
        while current_val<list[pos-1] and pos>0:
            list[pos]=list[pos-1]
            pos=pos-1
        list[pos]=current_val
    print(list)


sort(list)

        
