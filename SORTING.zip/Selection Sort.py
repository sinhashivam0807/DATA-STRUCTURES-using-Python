# selection sort

list=[2,5,3,31,25,2
      ,1,51,64,98,10,12]

def sort(list):
    for i in range(0,len(list)):
        min_val=i
        for j in range(i,len(list)):
            if list[j]<list[min_val]:
                min_val=j
        temp=list[i]
        list[i]=list[min_val]
        list[min_val]=temp
    

sort(list)
print(list)
